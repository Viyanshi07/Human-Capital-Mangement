.. highlight:: shell

============
Installation
============

At the command line:

.. code-block:: console

    $ pip install workday
