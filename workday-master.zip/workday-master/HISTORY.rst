=======
History
=======

0.4.0 (2018-06-27)
------------------

* Implemented paging by making WorkdayResponse objects iterable

0.3.0 (2018-06-23)
------------------

* Added test framework, setup package for distribution

0.2.0 (2018-06-22)
------------------

* WS-Security support
* Protected WSDL support
* Paging support

0.1.0 (2018-06-22)
------------------

* First release on PyPI.
* Template for Talent API (SOAP) method execution
